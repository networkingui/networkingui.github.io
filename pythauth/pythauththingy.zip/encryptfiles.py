from cryptography.fernet import Fernet
from getpass import getpass

key = Fernet.generate_key()

keys = "KEY"

decryptpass = "decryptADMINfiles"

cipher = Fernet(key)

data = "Ytvariety122@gmail.com, authey0011devofthissitesecurepasswordencrypt".encode()
print("By selecting 55 you can also decrypt data and access stored keys")
xxxx = input("Encrypt data? y/n\n")



#encrypt
if xxxx == "y":
  encryted_data = cipher.encrypt(data)
  print(encryted_data)
  with open('thekey.txt', "a") as file5:
    file5.write(str(key))
  
elif xxxx == "55":
  with open('thekey.txt', 'r') as file5:
   lines = file5.readlines()
   stored_keys = [lines[i].strip() for i in range(2, len(lines), 3)]
   xyxyx = input("Enter KEY to get key\n")
   if xyxyx == keys:
     print(stored_keys)
     inp = input("Would you like to decrypt? y/n\n")
     if inp == "y":
       inpu = getpass("Please enter dycrypt password\n")
       if inpu == decryptpass:
         with open('thekey.txt', 'rb') as file:
           encrypted_data = file.read()
         decrypted_data = cipher.decrypt(encrypted_data)
         print(decrypted_data.decode())
        
    
    


  



