from getpass import getpass
import subprocess
import tkinter as tk

def execute_script():
    file_path = "encryptfiles.py"
    subprocess.call(["python", file_path])

print("At this time make sure a output has been loaded to provide the GUI panel")
print("Loading user interface...")
print("Done")

sUserK = "00110011122"

xyx = getpass("Enter super user key to continue \nor press exit to exit program: ")

if xyx == sUserK:
    p1 = int(input("Loading secondary SU UI panel, press 1 to go or 2 to exit: "))
    if p1 == 1:
       print("Configuring...")
       print("DONE")
       root = tk.Tk()
       root.title("Python GUI Dev")
       label = tk.Label(root, text="Python User GUI")
       label.pack()
       button1 = tk.Button(root, text="Encyrpt user data", command=execute_script)
       button1.pack()
       button2 = tk.Button(root, text="Null")
       button2.pack()
       button3 = tk.Button(root, text="Null")
       button3.pack()
       root.mainloop()

        
        
    elif p1 == 2:
      print("Exiting...")
      exit()
