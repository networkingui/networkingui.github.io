
import subprocess
print("Loading Runtime...")
print("Welcome to my data storing project!")
print("What is your name?")
name = input("Please enter your full name:     ")
from getpass import getpass 
if name != "AdMIn001": 
  print("Welcome " + name + " You may follow the command line to get into a space. ")
if name == "AdMIn001":
  print("Welcome developer!")
  print("Please enter your su password to enter su space ")
  SU = getpass("SU Password:   ")
  if SU == "nullfornow":
    print("Authenticating...")
    print("Access granted, transfering to root")
    file_path = "UI.py"
    subprocess.call(["python", file_path])
    exit()


  else:
    print("Access denied, please try again.")
    exit()


Account = input("Do you have a account? y/n:      ")
Default1 = []
Default2 = []


# sign in below
if Account == "y":
    signin = input("Would you like to sign in now? y/n: ")

    if signin.lower() == "y":
        try:
            with open('user.py', 'r') as file:
                lines = file.readlines()
                stored_users = [lines[i].strip() for i in range(2, len(lines), 3)]
                stored_passwords = [lines[i].strip() for i in range(1, len(lines), 3)]

                username = input("Username: ")
                password = input("Password: ")

                if username in stored_users and password == stored_passwords[stored_users.index(username)]:
                    print("Sign in successful! do not forget your username and password there is limited capacity in our database ")
                    file_path2 = "userspace.py"
                    subprocess.call(["python", file_path2])
                else:
                    print("Invalid username or password")
        except FileNotFoundError:
            print("No accounts found. Please sign up first.")
    else:
        exit()



#sign up below
else:
  print("Please sign up below using your new username and password: \n")
  newuser = input("Username:  \n " )
  newpass = input("Password:  \n ")
  con = input("Please type confirm to create new account:    ")
  print("Your new username and password will be: " + newuser + " " + newpass)

  if con.lower() == "confirm":
    with open('user.py', 'a') as file:
        file.write(name + "\n" + newpass + "\n" + newuser + '\n')
    print("Account created!")

    signin = input("Would you like to sign in now? y/n: ")
    if signin.lower() == "y":
        with open('user.py', 'r') as file:
            lines = file.readlines()
            stored_users = [lines[i].strip() for i in range(2, len(lines), 3)]
            stored_passwords = [lines[i].strip() for i in range(1, len(lines), 3)]
            username = input("Username: ")
            password = input("Password: ")

            if username in stored_users and password == stored_passwords[stored_users.index(username)]:
                print("Sign in successful! Dont forget your password and username\n")
                file_path1 = "userspace.py"
                subprocess.call(["python", file_path1])
                exit()
            else:
                print("Invalid username or password")
    else:
        exit()










  else: 
    no = input("Continue without account y/n   ")
    if no == "y": 
      print("Redirecting")
      print("You are now in the default space")
    else:
      print("Ending proccess")
      exit()


  # Python terminal authenticator project
  # Made by Zach H. 2024